import xbmcaddon

MainBase = 'https://goo.gl/0OB6UP'
addon = xbmcaddon.Addon('plugin.video.superlistamilton')