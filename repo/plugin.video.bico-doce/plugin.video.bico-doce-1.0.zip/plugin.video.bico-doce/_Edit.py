import xbmcaddon

MainBase = 'https://goo.gl/c54yK4'
addon = xbmcaddon.Addon('plugin.video.bico-doce')